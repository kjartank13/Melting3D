﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;


public class MeltObject : MonoBehaviour {

	Vector3 downVec = new Vector3 (0, -1, 0);

	public float max;

	//The mesh
	Mesh mesh;

	Mesh collisionMesh;
	int collision;
//	float collisionMaxX;
//	float collisionMinX;
//	float collisionMaxZ;
//	float collisionMinZ;

	float bottom;


	float maxDist;
	float minDist;

	//All the vertices in the mesh
	Vector3[] vertices;

	//List of vertex connectons
	List<int>[] connections;
	float[,] distances;

	// Use this for initialization
	void Start () {

		bottom = 100000f;

//		collisionMaxX = -10000f;
//		collisionMinX = 10000f;
//		collisionMaxZ = -10000f;
//		collisionMinZ = 10000f;

		mesh = GetComponent<MeshFilter>().mesh;

		vertices = mesh.vertices;
		connections = new List<int>[vertices.Length];
		distances = new float[vertices.Length, vertices.Length];

		//initialize connection lists
		for (int x = 0; x < connections.Length; x++) {
			connections [x] = new List<int> ();
		}

		minDist = 20000f;
		maxDist = -1000f;
		for (int p = 0; p < vertices.Length; p++) {
			for (int q = 0; q < vertices.Length; q++) {
				distances [p, q] = Vector3.Distance (vertices [p], vertices [q]);
				if (distances [p, q] < minDist && distances[p, q] != 0)
					minDist = distances [p, q];
				if (distances [p, q] > maxDist)
					maxDist = distances [p, q];
			}
		}
//		maxDist *= 2;
		//build connection lists
//		for (int i = 0; i < mesh.triangles.Length; i += 3) {
//			int a = mesh.triangles [i];
//			int b = mesh.triangles [i + 1];
//			int c = mesh.triangles [i + 2];
////			Debug.Log (mesh.triangles [i] + " " + mesh.triangles [i + 1] + " " + mesh.triangles [i + 2]);
//			if (!connections[a].Contains(b))
//				connections [a].Add(b);
//			if (!connections [a].Contains (c))
//				connections [a].Add (c);
//
//			if (!connections[b].Contains(a))
//				connections [b].Add(a);
//			if (!connections [b].Contains (c))
//				connections [b].Add (c);
//
//			if (!connections[c].Contains(a))
//				connections [c].Add(a);
//			if (!connections [c].Contains (b))
//				connections [c].Add (b);
//		}
			
	}
	
	// Update is called once per frame
	void Update() {

		if (collision <= 0)
			return;

		if (GetComponent<Renderer> ().bounds.size.x > max)
			return;
		if (GetComponent<Renderer> ().bounds.size.z > max)
			return;
		
//		if (GetComponent<Renderer> ().bounds.size.y > 10)
//			return;
		
		int i = 0;

		for (int k = 0; k < vertices.Length; k++) {
			if (distances [i, k] < minDist && distances [i, k] != 0) {
				return;
			}
		}
		while (i < vertices.Length) {

//			vertices [i] += vertices[i].normalized * Time.deltaTime;
			float x = transform.TransformPoint(vertices[i]).x;
			float y = transform.TransformPoint(vertices[i]).y;
			float z = transform.TransformPoint(vertices[i]).z;

			if (y > bottom) {
				
				var sum = -Vector3.up * Time.deltaTime * (max - GetComponent<Renderer>().bounds.size.x)/max;

//				for (int k = 0; k < vertices.Length; k++) {
//					if (distances [i, k] < minDist && distances [i, k] != 0) {
//						sum = new Vector3 (0, 0, 0);
//					}
//				}
				vertices [i] += sum;

			} else {

				Vector3 norm = vertices [i].normalized;

				Vector3 n = new Vector3 (0, 0, 0);
				n.x = norm.x;
				n.y = 0;
				n.z = norm.z;

//				if (Vector3.Distance (new Vector3 (0, vertices [i].y, 0), vertices [i]) >= maxDist) {
//					n.x = 0;
//					n.z = 0;
//				}

//				if ((x > collisionMaxX && z > collisionMaxZ) || (x > collisionMaxX && z < collisionMinZ) 
//					|| (x < collisionMinX && z > collisionMaxZ) || (x < collisionMinX && z < collisionMinZ))
//					n = downVec;
				RaycastHit hit;
//				Debug.DrawRay (transform.TransformPoint(vertices [i]), vertices[i].normalized, Color.red);
				if (!Physics.Raycast (transform.TransformPoint(vertices [i]), -Vector3.up, out hit, 0.1f)) {
//					Debug.Log (hit.collider.name);
					n = -Vector3.up;
					if (hit.distance > 0.3) {
						vertices [i].y += 0.3f;
					}
				}
				vertices [i] += n * Time.deltaTime * 2 * (max - GetComponent<Renderer>().bounds.size.x)/max;

			}

			i++;
		}

		mesh.vertices = vertices;
		mesh.RecalculateBounds();
		mesh.RecalculateNormals();
	}

	void OnCollisionEnter(Collision other) {

//		foreach (ContactPoint contact in other.contacts) {
//			Debug.DrawRay(contact.point, contact.normal, Color.white);
//		}
		this.GetComponent<Rigidbody>().isKinematic = false;
		collision++;
		collisionMesh = other.collider.gameObject.GetComponent<MeshFilter> ().mesh;
		Vector3[] collVertices = collisionMesh.vertices;
//		for (int i = 0; i < collisionMesh.vertices.Length; i++) {
//			if (transform.TransformPoint (collisionMesh.vertices [i]).y > collisionTopY)
//				collisionTopY = transform.TransformPoint (collisionMesh.vertices [i]).y;
//		}

		for (int i = 0; i < vertices.Length; i++) {
			if (transform.TransformPoint(vertices [i]).y < bottom)
				bottom = transform.TransformPoint(vertices [i]).y;
		}
		bottom += 0.3f;

		for (int k = 0; k < vertices.Length; k++) {
			vertices [k].y += 0.3f;
		}

//		collisionMaxX = collisionMesh.bounds.max.x;
//		collisionMinX = collisionMesh.bounds.min.x;
//		collisionMaxZ = collisionMesh.bounds.max.z;
//		collisionMinZ = collisionMesh.bounds.min.z;



	}
						
	void OnCollisionExit(Collision collisionInfo) {
		collision--;
	}



}
